﻿namespace Deal_or_no_Deal
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.DealButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.NoDealButton = new System.Windows.Forms.Button();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.currentOffer = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.MyCase = new System.Windows.Forms.Label();
            this.InstructionsLabel = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.lblonepenny = new System.Windows.Forms.Label();
            this.lbl1000 = new System.Windows.Forms.Label();
            this.lbl1 = new System.Windows.Forms.Label();
            this.lbl5000 = new System.Windows.Forms.Label();
            this.lbl5 = new System.Windows.Forms.Label();
            this.lbl10000 = new System.Windows.Forms.Label();
            this.lbl10 = new System.Windows.Forms.Label();
            this.lbl25000 = new System.Windows.Forms.Label();
            this.lbl25 = new System.Windows.Forms.Label();
            this.lbl50000 = new System.Windows.Forms.Label();
            this.lbl50 = new System.Windows.Forms.Label();
            this.lbl75000 = new System.Windows.Forms.Label();
            this.lbl75 = new System.Windows.Forms.Label();
            this.lbl100000 = new System.Windows.Forms.Label();
            this.lbl100 = new System.Windows.Forms.Label();
            this.lbl200000 = new System.Windows.Forms.Label();
            this.lbl200 = new System.Windows.Forms.Label();
            this.lbl300000 = new System.Windows.Forms.Label();
            this.lbl300 = new System.Windows.Forms.Label();
            this.lbl400000 = new System.Windows.Forms.Label();
            this.lbl400 = new System.Windows.Forms.Label();
            this.lbl500000 = new System.Windows.Forms.Label();
            this.lbl500 = new System.Windows.Forms.Label();
            this.lbl750000 = new System.Windows.Forms.Label();
            this.lbl750 = new System.Windows.Forms.Label();
            this.lbl1000000 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.PastOffersListView = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label5 = new System.Windows.Forms.Label();
            this.Scores = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.HighScore = new System.Windows.Forms.Label();
            this.AverageScore = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.NameTextBox = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.DealOfferPanel = new System.Windows.Forms.Panel();
            this.UserNamePanel = new System.Windows.Forms.Panel();
            this.SubmitName = new System.Windows.Forms.Button();
            this.CaseSelectionTimer = new System.Windows.Forms.Timer(this.components);
            this.panel1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.DealOfferPanel.SuspendLayout();
            this.UserNamePanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // DealButton
            // 
            this.DealButton.Enabled = false;
            this.DealButton.Location = new System.Drawing.Point(18, 35);
            this.DealButton.Name = "DealButton";
            this.DealButton.Size = new System.Drawing.Size(75, 23);
            this.DealButton.TabIndex = 0;
            this.DealButton.Text = "Deal";
            this.DealButton.UseVisualStyleBackColor = true;
            this.DealButton.Click += new System.EventHandler(this.DealButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(22, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(206, 31);
            this.label1.TabIndex = 1;
            this.label1.Text = "Deal or No Deal";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.PastOffersListView);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.tableLayoutPanel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel1.Location = new System.Drawing.Point(320, 108);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(650, 389);
            this.panel1.TabIndex = 2;
            // 
            // NoDealButton
            // 
            this.NoDealButton.Enabled = false;
            this.NoDealButton.Location = new System.Drawing.Point(121, 35);
            this.NoDealButton.Name = "NoDealButton";
            this.NoDealButton.Size = new System.Drawing.Size(75, 23);
            this.NoDealButton.TabIndex = 4;
            this.NoDealButton.Text = "No Deal";
            this.NoDealButton.UseVisualStyleBackColor = true;
            this.NoDealButton.Click += new System.EventHandler(this.NoDealButton_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.button26, 1, 12);
            this.tableLayoutPanel1.Controls.Add(this.button25, 0, 12);
            this.tableLayoutPanel1.Controls.Add(this.button24, 1, 11);
            this.tableLayoutPanel1.Controls.Add(this.button23, 0, 11);
            this.tableLayoutPanel1.Controls.Add(this.button22, 1, 10);
            this.tableLayoutPanel1.Controls.Add(this.button21, 0, 10);
            this.tableLayoutPanel1.Controls.Add(this.button20, 1, 9);
            this.tableLayoutPanel1.Controls.Add(this.button19, 0, 9);
            this.tableLayoutPanel1.Controls.Add(this.button18, 1, 8);
            this.tableLayoutPanel1.Controls.Add(this.button17, 0, 8);
            this.tableLayoutPanel1.Controls.Add(this.button16, 1, 7);
            this.tableLayoutPanel1.Controls.Add(this.button15, 0, 7);
            this.tableLayoutPanel1.Controls.Add(this.button14, 1, 6);
            this.tableLayoutPanel1.Controls.Add(this.button13, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.button12, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.button11, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.button10, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.button9, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.button8, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.button7, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.button6, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.button5, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.button4, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.button3, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.button2, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.button1, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 108);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 13;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(320, 389);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.UserNamePanel);
            this.panel2.Controls.Add(this.DealOfferPanel);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.InstructionsLabel);
            this.panel2.Controls.Add(this.AverageScore);
            this.panel2.Controls.Add(this.HighScore);
            this.panel2.Controls.Add(this.MyCase);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(970, 108);
            this.panel2.TabIndex = 5;
            // 
            // button1
            // 
            this.button1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button1.Location = new System.Drawing.Point(3, 3);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(154, 24);
            this.button1.TabIndex = 0;
            this.button1.Text = "1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // button2
            // 
            this.button2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button2.Location = new System.Drawing.Point(163, 3);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(154, 24);
            this.button2.TabIndex = 1;
            this.button2.Text = "2";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.Button1_Click);
            // 
            // button3
            // 
            this.button3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button3.Location = new System.Drawing.Point(3, 33);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(154, 24);
            this.button3.TabIndex = 2;
            this.button3.Text = "3";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.Button1_Click);
            // 
            // button4
            // 
            this.button4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button4.Location = new System.Drawing.Point(163, 33);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(154, 24);
            this.button4.TabIndex = 3;
            this.button4.Text = "4";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.Button1_Click);
            // 
            // button5
            // 
            this.button5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button5.Location = new System.Drawing.Point(3, 63);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(154, 24);
            this.button5.TabIndex = 4;
            this.button5.Text = "5";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.Button1_Click);
            // 
            // button6
            // 
            this.button6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button6.Location = new System.Drawing.Point(163, 63);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(154, 24);
            this.button6.TabIndex = 5;
            this.button6.Text = "6";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.Button1_Click);
            // 
            // button7
            // 
            this.button7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button7.Location = new System.Drawing.Point(3, 93);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(154, 24);
            this.button7.TabIndex = 6;
            this.button7.Text = "7";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.Button1_Click);
            // 
            // button8
            // 
            this.button8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button8.Location = new System.Drawing.Point(163, 93);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(154, 24);
            this.button8.TabIndex = 7;
            this.button8.Text = "8";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.Button1_Click);
            // 
            // button9
            // 
            this.button9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button9.Location = new System.Drawing.Point(3, 123);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(154, 24);
            this.button9.TabIndex = 8;
            this.button9.Text = "9";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.Button1_Click);
            // 
            // button10
            // 
            this.button10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button10.Location = new System.Drawing.Point(163, 123);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(154, 24);
            this.button10.TabIndex = 9;
            this.button10.Text = "10";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.Button1_Click);
            // 
            // button11
            // 
            this.button11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button11.Location = new System.Drawing.Point(3, 153);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(154, 24);
            this.button11.TabIndex = 10;
            this.button11.Text = "11";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.Button1_Click);
            // 
            // button12
            // 
            this.button12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button12.Location = new System.Drawing.Point(163, 153);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(154, 24);
            this.button12.TabIndex = 11;
            this.button12.Text = "12";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.Button1_Click);
            // 
            // button13
            // 
            this.button13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button13.Location = new System.Drawing.Point(3, 183);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(154, 24);
            this.button13.TabIndex = 12;
            this.button13.Text = "13";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.Button1_Click);
            // 
            // button14
            // 
            this.button14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button14.Location = new System.Drawing.Point(163, 183);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(154, 24);
            this.button14.TabIndex = 13;
            this.button14.Text = "14";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.Button1_Click);
            // 
            // button15
            // 
            this.button15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button15.Location = new System.Drawing.Point(3, 213);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(154, 24);
            this.button15.TabIndex = 14;
            this.button15.Text = "15";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.Button1_Click);
            // 
            // button16
            // 
            this.button16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button16.Location = new System.Drawing.Point(163, 213);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(154, 24);
            this.button16.TabIndex = 15;
            this.button16.Text = "16";
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.Button1_Click);
            // 
            // button17
            // 
            this.button17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button17.Location = new System.Drawing.Point(3, 243);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(154, 24);
            this.button17.TabIndex = 16;
            this.button17.Text = "17";
            this.button17.UseVisualStyleBackColor = true;
            this.button17.Click += new System.EventHandler(this.Button1_Click);
            // 
            // button18
            // 
            this.button18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button18.Location = new System.Drawing.Point(163, 243);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(154, 24);
            this.button18.TabIndex = 17;
            this.button18.Text = "18";
            this.button18.UseVisualStyleBackColor = true;
            this.button18.Click += new System.EventHandler(this.Button1_Click);
            // 
            // button19
            // 
            this.button19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button19.Location = new System.Drawing.Point(3, 273);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(154, 24);
            this.button19.TabIndex = 18;
            this.button19.Text = "19";
            this.button19.UseVisualStyleBackColor = true;
            this.button19.Click += new System.EventHandler(this.Button1_Click);
            // 
            // button20
            // 
            this.button20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button20.Location = new System.Drawing.Point(163, 273);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(154, 24);
            this.button20.TabIndex = 19;
            this.button20.Text = "20";
            this.button20.UseVisualStyleBackColor = true;
            this.button20.Click += new System.EventHandler(this.Button1_Click);
            // 
            // button21
            // 
            this.button21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button21.Location = new System.Drawing.Point(3, 303);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(154, 24);
            this.button21.TabIndex = 20;
            this.button21.Text = "21";
            this.button21.UseVisualStyleBackColor = true;
            this.button21.Click += new System.EventHandler(this.Button1_Click);
            // 
            // button22
            // 
            this.button22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button22.Location = new System.Drawing.Point(163, 303);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(154, 24);
            this.button22.TabIndex = 21;
            this.button22.Text = "22";
            this.button22.UseVisualStyleBackColor = true;
            this.button22.Click += new System.EventHandler(this.Button1_Click);
            // 
            // button23
            // 
            this.button23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button23.Location = new System.Drawing.Point(3, 333);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(154, 24);
            this.button23.TabIndex = 22;
            this.button23.Text = "23";
            this.button23.UseVisualStyleBackColor = true;
            this.button23.Click += new System.EventHandler(this.Button1_Click);
            // 
            // button24
            // 
            this.button24.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button24.Location = new System.Drawing.Point(163, 333);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(154, 24);
            this.button24.TabIndex = 23;
            this.button24.Text = "24";
            this.button24.UseVisualStyleBackColor = true;
            this.button24.Click += new System.EventHandler(this.Button1_Click);
            // 
            // button25
            // 
            this.button25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button25.Location = new System.Drawing.Point(3, 363);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(154, 24);
            this.button25.TabIndex = 24;
            this.button25.Text = "25";
            this.button25.UseVisualStyleBackColor = true;
            this.button25.Click += new System.EventHandler(this.Button1_Click);
            // 
            // button26
            // 
            this.button26.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button26.Location = new System.Drawing.Point(163, 363);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(154, 24);
            this.button26.TabIndex = 25;
            this.button26.Text = "26";
            this.button26.UseVisualStyleBackColor = true;
            this.button26.Click += new System.EventHandler(this.Button1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(15, 6);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(81, 18);
            this.label2.TabIndex = 5;
            this.label2.Text = "Your offer: ";
            // 
            // currentOffer
            // 
            this.currentOffer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.currentOffer.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.currentOffer.Location = new System.Drawing.Point(102, 1);
            this.currentOffer.Name = "currentOffer";
            this.currentOffer.Size = new System.Drawing.Size(94, 26);
            this.currentOffer.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(25, 48);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(83, 18);
            this.label4.TabIndex = 5;
            this.label4.Text = "Your case: ";
            // 
            // MyCase
            // 
            this.MyCase.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.MyCase.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MyCase.Location = new System.Drawing.Point(112, 43);
            this.MyCase.Name = "MyCase";
            this.MyCase.Size = new System.Drawing.Size(94, 26);
            this.MyCase.TabIndex = 5;
            // 
            // InstructionsLabel
            // 
            this.InstructionsLabel.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.InstructionsLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InstructionsLabel.Location = new System.Drawing.Point(0, 77);
            this.InstructionsLabel.Name = "InstructionsLabel";
            this.InstructionsLabel.Size = new System.Drawing.Size(970, 31);
            this.InstructionsLabel.TabIndex = 6;
            this.InstructionsLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.Scores);
            this.panel3.Controls.Add(this.label5);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel3.Location = new System.Drawing.Point(0, 497);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(970, 143);
            this.panel3.TabIndex = 6;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.BackColor = System.Drawing.Color.LemonChiffon;
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Controls.Add(this.lbl1000000, 1, 12);
            this.tableLayoutPanel2.Controls.Add(this.lbl750, 0, 12);
            this.tableLayoutPanel2.Controls.Add(this.lbl750000, 1, 11);
            this.tableLayoutPanel2.Controls.Add(this.lbl500, 0, 11);
            this.tableLayoutPanel2.Controls.Add(this.lbl500000, 1, 10);
            this.tableLayoutPanel2.Controls.Add(this.lbl400, 0, 10);
            this.tableLayoutPanel2.Controls.Add(this.lbl400000, 1, 9);
            this.tableLayoutPanel2.Controls.Add(this.lbl300, 0, 9);
            this.tableLayoutPanel2.Controls.Add(this.lbl300000, 1, 8);
            this.tableLayoutPanel2.Controls.Add(this.lbl200, 0, 8);
            this.tableLayoutPanel2.Controls.Add(this.lbl200000, 1, 7);
            this.tableLayoutPanel2.Controls.Add(this.lbl100, 0, 7);
            this.tableLayoutPanel2.Controls.Add(this.lbl100000, 1, 6);
            this.tableLayoutPanel2.Controls.Add(this.lbl75, 0, 6);
            this.tableLayoutPanel2.Controls.Add(this.lbl75000, 1, 5);
            this.tableLayoutPanel2.Controls.Add(this.lbl50, 0, 5);
            this.tableLayoutPanel2.Controls.Add(this.lbl50000, 1, 4);
            this.tableLayoutPanel2.Controls.Add(this.lbl25, 0, 4);
            this.tableLayoutPanel2.Controls.Add(this.lbl25000, 1, 3);
            this.tableLayoutPanel2.Controls.Add(this.lbl10, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.lbl10000, 1, 2);
            this.tableLayoutPanel2.Controls.Add(this.lbl5, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.lbl5000, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.lbl1, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.lbl1000, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.lblonepenny, 0, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 13;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(203, 389);
            this.tableLayoutPanel2.TabIndex = 1;
            // 
            // lblonepenny
            // 
            this.lblonepenny.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblonepenny.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblonepenny.Location = new System.Drawing.Point(3, 0);
            this.lblonepenny.Name = "lblonepenny";
            this.lblonepenny.Size = new System.Drawing.Size(95, 30);
            this.lblonepenny.TabIndex = 0;
            this.lblonepenny.Text = "0.01";
            this.lblonepenny.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl1000
            // 
            this.lbl1000.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl1000.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1000.Location = new System.Drawing.Point(104, 0);
            this.lbl1000.Name = "lbl1000";
            this.lbl1000.Size = new System.Drawing.Size(96, 30);
            this.lbl1000.TabIndex = 1;
            this.lbl1000.Text = "1,000";
            this.lbl1000.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl1
            // 
            this.lbl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1.Location = new System.Drawing.Point(3, 30);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(95, 30);
            this.lbl1.TabIndex = 2;
            this.lbl1.Text = "1";
            this.lbl1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl5000
            // 
            this.lbl5000.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl5000.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl5000.Location = new System.Drawing.Point(104, 30);
            this.lbl5000.Name = "lbl5000";
            this.lbl5000.Size = new System.Drawing.Size(96, 30);
            this.lbl5000.TabIndex = 3;
            this.lbl5000.Text = "5,000";
            this.lbl5000.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl5
            // 
            this.lbl5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl5.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl5.Location = new System.Drawing.Point(3, 60);
            this.lbl5.Name = "lbl5";
            this.lbl5.Size = new System.Drawing.Size(95, 30);
            this.lbl5.TabIndex = 4;
            this.lbl5.Text = "5";
            this.lbl5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl10000
            // 
            this.lbl10000.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl10000.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl10000.Location = new System.Drawing.Point(104, 60);
            this.lbl10000.Name = "lbl10000";
            this.lbl10000.Size = new System.Drawing.Size(96, 30);
            this.lbl10000.TabIndex = 5;
            this.lbl10000.Text = "10,000";
            this.lbl10000.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl10
            // 
            this.lbl10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl10.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl10.Location = new System.Drawing.Point(3, 90);
            this.lbl10.Name = "lbl10";
            this.lbl10.Size = new System.Drawing.Size(95, 30);
            this.lbl10.TabIndex = 6;
            this.lbl10.Text = "10";
            this.lbl10.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl25000
            // 
            this.lbl25000.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl25000.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl25000.Location = new System.Drawing.Point(104, 90);
            this.lbl25000.Name = "lbl25000";
            this.lbl25000.Size = new System.Drawing.Size(96, 30);
            this.lbl25000.TabIndex = 7;
            this.lbl25000.Text = "25,000";
            this.lbl25000.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl25
            // 
            this.lbl25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl25.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl25.Location = new System.Drawing.Point(3, 120);
            this.lbl25.Name = "lbl25";
            this.lbl25.Size = new System.Drawing.Size(95, 30);
            this.lbl25.TabIndex = 8;
            this.lbl25.Text = "25";
            this.lbl25.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl50000
            // 
            this.lbl50000.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl50000.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl50000.Location = new System.Drawing.Point(104, 120);
            this.lbl50000.Name = "lbl50000";
            this.lbl50000.Size = new System.Drawing.Size(96, 30);
            this.lbl50000.TabIndex = 9;
            this.lbl50000.Text = "50,000";
            this.lbl50000.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl50
            // 
            this.lbl50.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl50.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl50.Location = new System.Drawing.Point(3, 150);
            this.lbl50.Name = "lbl50";
            this.lbl50.Size = new System.Drawing.Size(95, 30);
            this.lbl50.TabIndex = 10;
            this.lbl50.Text = "50";
            this.lbl50.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl75000
            // 
            this.lbl75000.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl75000.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl75000.Location = new System.Drawing.Point(104, 150);
            this.lbl75000.Name = "lbl75000";
            this.lbl75000.Size = new System.Drawing.Size(96, 30);
            this.lbl75000.TabIndex = 11;
            this.lbl75000.Text = "75,000";
            this.lbl75000.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl75
            // 
            this.lbl75.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl75.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl75.Location = new System.Drawing.Point(3, 180);
            this.lbl75.Name = "lbl75";
            this.lbl75.Size = new System.Drawing.Size(95, 30);
            this.lbl75.TabIndex = 12;
            this.lbl75.Text = "75";
            this.lbl75.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl100000
            // 
            this.lbl100000.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl100000.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl100000.Location = new System.Drawing.Point(104, 180);
            this.lbl100000.Name = "lbl100000";
            this.lbl100000.Size = new System.Drawing.Size(96, 30);
            this.lbl100000.TabIndex = 13;
            this.lbl100000.Text = "100,000";
            this.lbl100000.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl100
            // 
            this.lbl100.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl100.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl100.Location = new System.Drawing.Point(3, 210);
            this.lbl100.Name = "lbl100";
            this.lbl100.Size = new System.Drawing.Size(95, 30);
            this.lbl100.TabIndex = 14;
            this.lbl100.Text = "100";
            this.lbl100.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl200000
            // 
            this.lbl200000.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl200000.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl200000.Location = new System.Drawing.Point(104, 210);
            this.lbl200000.Name = "lbl200000";
            this.lbl200000.Size = new System.Drawing.Size(96, 30);
            this.lbl200000.TabIndex = 15;
            this.lbl200000.Text = "200,000";
            this.lbl200000.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl200
            // 
            this.lbl200.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl200.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl200.Location = new System.Drawing.Point(3, 240);
            this.lbl200.Name = "lbl200";
            this.lbl200.Size = new System.Drawing.Size(95, 30);
            this.lbl200.TabIndex = 16;
            this.lbl200.Text = "200";
            this.lbl200.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl300000
            // 
            this.lbl300000.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl300000.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl300000.Location = new System.Drawing.Point(104, 240);
            this.lbl300000.Name = "lbl300000";
            this.lbl300000.Size = new System.Drawing.Size(96, 30);
            this.lbl300000.TabIndex = 17;
            this.lbl300000.Text = "300,000";
            this.lbl300000.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl300
            // 
            this.lbl300.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl300.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl300.Location = new System.Drawing.Point(3, 270);
            this.lbl300.Name = "lbl300";
            this.lbl300.Size = new System.Drawing.Size(95, 30);
            this.lbl300.TabIndex = 18;
            this.lbl300.Text = "300";
            this.lbl300.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl400000
            // 
            this.lbl400000.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl400000.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl400000.Location = new System.Drawing.Point(104, 270);
            this.lbl400000.Name = "lbl400000";
            this.lbl400000.Size = new System.Drawing.Size(96, 30);
            this.lbl400000.TabIndex = 19;
            this.lbl400000.Text = "400,000";
            this.lbl400000.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl400
            // 
            this.lbl400.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl400.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl400.Location = new System.Drawing.Point(3, 300);
            this.lbl400.Name = "lbl400";
            this.lbl400.Size = new System.Drawing.Size(95, 30);
            this.lbl400.TabIndex = 20;
            this.lbl400.Text = "400";
            this.lbl400.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl500000
            // 
            this.lbl500000.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl500000.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl500000.Location = new System.Drawing.Point(104, 300);
            this.lbl500000.Name = "lbl500000";
            this.lbl500000.Size = new System.Drawing.Size(96, 30);
            this.lbl500000.TabIndex = 21;
            this.lbl500000.Text = "500,000";
            this.lbl500000.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl500
            // 
            this.lbl500.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl500.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl500.Location = new System.Drawing.Point(3, 330);
            this.lbl500.Name = "lbl500";
            this.lbl500.Size = new System.Drawing.Size(95, 30);
            this.lbl500.TabIndex = 22;
            this.lbl500.Text = "500";
            this.lbl500.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl750000
            // 
            this.lbl750000.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl750000.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl750000.Location = new System.Drawing.Point(104, 330);
            this.lbl750000.Name = "lbl750000";
            this.lbl750000.Size = new System.Drawing.Size(96, 30);
            this.lbl750000.TabIndex = 23;
            this.lbl750000.Text = "750,000";
            this.lbl750000.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl750
            // 
            this.lbl750.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl750.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl750.Location = new System.Drawing.Point(3, 360);
            this.lbl750.Name = "lbl750";
            this.lbl750.Size = new System.Drawing.Size(95, 30);
            this.lbl750.TabIndex = 24;
            this.lbl750.Text = "750";
            this.lbl750.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl1000000
            // 
            this.lbl1000000.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl1000000.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1000000.Location = new System.Drawing.Point(104, 360);
            this.lbl1000000.Name = "lbl1000000";
            this.lbl1000000.Size = new System.Drawing.Size(96, 30);
            this.lbl1000000.TabIndex = 25;
            this.lbl1000000.Text = "1,000,000";
            this.lbl1000000.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label3
            // 
            this.label3.Dock = System.Windows.Forms.DockStyle.Top;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(203, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(447, 23);
            this.label3.TabIndex = 2;
            this.label3.Text = "Past Offers";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // PastOffersListView
            // 
            this.PastOffersListView.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1});
            this.PastOffersListView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PastOffersListView.Location = new System.Drawing.Point(203, 23);
            this.PastOffersListView.Name = "PastOffersListView";
            this.PastOffersListView.Size = new System.Drawing.Size(447, 366);
            this.PastOffersListView.TabIndex = 3;
            this.PastOffersListView.UseCompatibleStateImageBehavior = false;
            this.PastOffersListView.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Past Offers";
            this.columnHeader1.Width = 245;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Dock = System.Windows.Forms.DockStyle.Top;
            this.label5.Location = new System.Drawing.Point(0, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(43, 13);
            this.label5.TabIndex = 0;
            this.label5.Text = "Scores:";
            // 
            // Scores
            // 
            this.Scores.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Scores.Location = new System.Drawing.Point(0, 13);
            this.Scores.Multiline = true;
            this.Scores.Name = "Scores";
            this.Scores.ReadOnly = true;
            this.Scores.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.Scores.Size = new System.Drawing.Size(970, 130);
            this.Scores.TabIndex = 1;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(751, 9);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(61, 13);
            this.label6.TabIndex = 7;
            this.label6.Text = "High score:";
            this.label6.Click += new System.EventHandler(this.Label6_Click);
            // 
            // HighScore
            // 
            this.HighScore.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.HighScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HighScore.Location = new System.Drawing.Point(830, 6);
            this.HighScore.Name = "HighScore";
            this.HighScore.Size = new System.Drawing.Size(94, 26);
            this.HighScore.TabIndex = 5;
            // 
            // AverageScore
            // 
            this.AverageScore.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.AverageScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AverageScore.Location = new System.Drawing.Point(830, 43);
            this.AverageScore.Name = "AverageScore";
            this.AverageScore.Size = new System.Drawing.Size(94, 26);
            this.AverageScore.TabIndex = 5;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(751, 46);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(79, 13);
            this.label8.TabIndex = 7;
            this.label8.Text = "Average score:";
            this.label8.Click += new System.EventHandler(this.Label6_Click);
            // 
            // NameTextBox
            // 
            this.NameTextBox.Location = new System.Drawing.Point(48, 6);
            this.NameTextBox.Name = "NameTextBox";
            this.NameTextBox.Size = new System.Drawing.Size(144, 20);
            this.NameTextBox.TabIndex = 8;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(4, 9);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(38, 13);
            this.label7.TabIndex = 9;
            this.label7.Text = "Name:";
            // 
            // DealOfferPanel
            // 
            this.DealOfferPanel.Controls.Add(this.label2);
            this.DealOfferPanel.Controls.Add(this.NoDealButton);
            this.DealOfferPanel.Controls.Add(this.DealButton);
            this.DealOfferPanel.Controls.Add(this.currentOffer);
            this.DealOfferPanel.Location = new System.Drawing.Point(380, 10);
            this.DealOfferPanel.Name = "DealOfferPanel";
            this.DealOfferPanel.Size = new System.Drawing.Size(200, 64);
            this.DealOfferPanel.TabIndex = 10;
            this.DealOfferPanel.Visible = false;
            // 
            // UserNamePanel
            // 
            this.UserNamePanel.Controls.Add(this.SubmitName);
            this.UserNamePanel.Controls.Add(this.NameTextBox);
            this.UserNamePanel.Controls.Add(this.label7);
            this.UserNamePanel.Location = new System.Drawing.Point(370, 16);
            this.UserNamePanel.Name = "UserNamePanel";
            this.UserNamePanel.Size = new System.Drawing.Size(316, 30);
            this.UserNamePanel.TabIndex = 11;
            // 
            // SubmitName
            // 
            this.SubmitName.Location = new System.Drawing.Point(217, 4);
            this.SubmitName.Name = "SubmitName";
            this.SubmitName.Size = new System.Drawing.Size(75, 23);
            this.SubmitName.TabIndex = 10;
            this.SubmitName.Text = "Submit";
            this.SubmitName.UseVisualStyleBackColor = true;
            this.SubmitName.Click += new System.EventHandler(this.SubmitName_Click);
            // 
            // CaseSelectionTimer
            // 
            this.CaseSelectionTimer.Interval = 3250;
            this.CaseSelectionTimer.Tick += new System.EventHandler(this.CaseSelectionTimer_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(970, 640);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel3);
            this.Name = "Form1";
            this.Text = "Deal or no deal";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.DealOfferPanel.ResumeLayout(false);
            this.DealOfferPanel.PerformLayout();
            this.UserNamePanel.ResumeLayout(false);
            this.UserNamePanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button DealButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button NoDealButton;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label currentOffer;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label MyCase;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label InstructionsLabel;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Label lbl1000000;
        private System.Windows.Forms.Label lbl750;
        private System.Windows.Forms.Label lbl750000;
        private System.Windows.Forms.Label lbl500;
        private System.Windows.Forms.Label lbl500000;
        private System.Windows.Forms.Label lbl400;
        private System.Windows.Forms.Label lbl400000;
        private System.Windows.Forms.Label lbl300;
        private System.Windows.Forms.Label lbl300000;
        private System.Windows.Forms.Label lbl200;
        private System.Windows.Forms.Label lbl200000;
        private System.Windows.Forms.Label lbl100;
        private System.Windows.Forms.Label lbl100000;
        private System.Windows.Forms.Label lbl75;
        private System.Windows.Forms.Label lbl75000;
        private System.Windows.Forms.Label lbl50;
        private System.Windows.Forms.Label lbl50000;
        private System.Windows.Forms.Label lbl25;
        private System.Windows.Forms.Label lbl25000;
        private System.Windows.Forms.Label lbl10;
        private System.Windows.Forms.Label lbl10000;
        private System.Windows.Forms.Label lbl5;
        private System.Windows.Forms.Label lbl5000;
        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.Label lbl1000;
        private System.Windows.Forms.Label lblonepenny;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.ListView PastOffersListView;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox Scores;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label HighScore;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label AverageScore;
        private System.Windows.Forms.Panel UserNamePanel;
        private System.Windows.Forms.Button SubmitName;
        private System.Windows.Forms.TextBox NameTextBox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel DealOfferPanel;
        private System.Windows.Forms.Timer CaseSelectionTimer;
    }
}

