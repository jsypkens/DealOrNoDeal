﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Deal_or_no_Deal
{
    public partial class Form1 : Form
    {
        public int RoundNumber = 1;
        public bool SelectingCase = true;
        public int SelectedCase = 0;
        public bool MakingOffer = false;
        public string UserName = "";
        public int CasesRemaining = 0;
        public bool AnimatingCase = false;

        public Dictionary<int, double> CaseValues = new Dictionary<int, double>();

        List<double> AllCaseValues = new List<double>()
        {
            0.01, 1, 5, 10, 25, 50, 75, 100, 200, 300, 400, 500, 750, 1000, 5000, 10000, 25000, 50000, 75000, 100000, 200000, 300000, 400000, 500000, 750000, 1000000
        };

        List<double> RemainingCaseValues = new List<double>()
        {
            0.01, 1, 5, 10, 25, 50, 75, 100, 200, 300, 400, 500, 750, 1000, 5000, 10000, 25000, 50000, 75000, 100000, 200000, 300000, 400000, 500000, 750000, 1000000
        };

        public Form1()
        {
            
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Random random = new Random();
            LoadScores();
            InstructionsLabel.Text = "Please enter your name";
            //InstructionsLabel.Text = "Please select your case";
            for (int i = 1; i <= 26; i++)
            {
                int selectedIndex = random.Next(0, AllCaseValues.Count);
                if (AllCaseValues.Count == 1)
                    selectedIndex = 0;
                double CaseValue = AllCaseValues[selectedIndex];
                AllCaseValues.Remove(CaseValue);
                CaseValues.Add(i, CaseValue);
            }
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            //System.Media.SoundPlayer player = new System.Media.SoundPlayer(Application.StartupPath + @"\DOND-goodCase.wav");
            //player.Play();
            
            //System.Media.SoundPlayer player2 = new System.Media.SoundPlayer(Application.StartupPath + @"\DOND-BadCase.wav");
            //player2.Play();


            if (MakingOffer || UserName == "" || AnimatingCase)
                return;

            int CurrentCase = Convert.ToInt32((sender as Button).Name.Replace("button", ""));


            if (SelectingCase)
            {
                SelectedCase = CurrentCase;
                MyCase.Text = SelectedCase.ToString();
                SelectingCase = false;

                CasesRemaining = 6;
                InstructionsLabel.Text = $"Please select {CasesRemaining} case" + (CasesRemaining != 1 ? "s" : "");
                Button button = sender as Button;
                button.Visible = false;

            }
            else
            {
                if (CasesRemaining > 0)
                {
                    CasesRemaining--;
                    RemainingCaseValues.Remove(CaseValues[CurrentCase]);
                    (sender as Button).Tag = CaseValues[CurrentCase].ToString(); //"1000";

                    if (CaseValues[CurrentCase] >= 50000)
                    {
                        using (System.Media.SoundPlayer playerBad = new System.Media.SoundPlayer(Application.StartupPath + @"\DOND-BadCase.wav"))
                        {
                            playerBad.Play();
                        }
                    }
                    else
                    {
                        using (System.Media.SoundPlayer playerGood = new System.Media.SoundPlayer(Application.StartupPath + @"\DOND-GoodCase.wav"))
                        {
                            playerGood.Play();
                        }
                    }


                    //(sender as Button).BackColor = Color.LightBlue;
                    //(sender as Button).ForeColor = Color.Black;
                    //(sender as Button).Enabled = false;
                    //(sender as Button).Visible = false;
                    CaseSelectionTimer.Tag = sender;
                    CaseSelectionTimer.Start();

                    if (CaseValues[CurrentCase] == 0.01)
                    {
                        lblonepenny.BackColor = Color.DarkGray;
                        lblonepenny.ForeColor = Color.White;
                    }
                    else
                    {
                        //foreach (var label in tableLayoutPanel2.Controls)
                        //{
                        //    if (label is Label)
                        //    {
                        //        if ((label as Label).Name.Replace("lbl", "") == CaseValues[CurrentCase].ToString())
                        //        {
                        //            (label as Label).BackColor = Color.DarkGray;
                        //            (label as Label).ForeColor = Color.White;
                        //            break;
                        //        }
                        //    }
                        //}
                    }
                    if (RemainingCaseValues.Count() == 1)
                    {
                        InstructionsLabel.Text = $"Your case had: {RemainingCaseValues[0]} ";
                        System.IO.File.AppendAllText(Application.StartupPath + @"\scores.txt", UserName + ": " + RemainingCaseValues[0] + Environment.NewLine);
                        LoadScores();
                        return;
                    }

                    InstructionsLabel.Text = $"Please select {CasesRemaining} cases";

                }

                //https://www.reddit.com/r/askmath/comments/696pxs/deal_or_no_deal_figuring_out_the_deal_formula/


                // $12,275.30 + (0.748 * E) - (2714.74 * C) - (0.40 * M) + (.0000006986 * E^2) + (32.623 * C^2)
                //where E is the expected value of the contestant's case (i.e. the arithmetic mean of all remaining values), C is the number of cases remaining,
                //and M is the maximum value on the board. Bradley notes that there's some fudge factor and probably a random number generator involved at some 
                //point, but claims that his formula "explain[s] 99% of the variance in the banker's offer."

                double E = RemainingCaseValues.Average();
                double M = RemainingCaseValues.Max();
                double C = RemainingCaseValues.Count();

                if (CasesRemaining == 0)
                {
                    DealButton.Enabled = true;
                    NoDealButton.Enabled = true;

                    //make an offer
                    //currentOffer.Text = RemainingCaseValues.Average().ToString();
                    double offerRaw = 12275.30 + (0.748 * E) - (2714.74 * C) - (0.040 * M) + (.0000006986 * Math.Pow(E, 2)) + (32.623 * Math.Pow(C, 2));

                    if (RoundNumber == 1)
                        offerRaw /= 3;

                    double offerRound;

                    if (offerRaw > M)
                        offerRaw = E;

                    if (offerRaw < 10000)
                        offerRound = Math.Round(offerRaw / 100.0) * 100;
                    else
                        offerRound = Math.Round(offerRaw / 1000.0) * 1000;

                   

                    currentOffer.Text = offerRound.ToString();
                    InstructionsLabel.Text = $"MAKE A CHOICE - DEAL OR NO DEAL!!  If you say no deal, you will have to open {CasesToOpen()} cases.";
                    MakingOffer = true;
                    PastOffersListView.Items.Add(offerRound.ToString());
                }

            }
        }

        public int CasesToOpen()
        {
            switch (RoundNumber)
            {
                case 1:
                    return 5;                    
                case 2:
                    return 4;
                case 3:
                    return 3;
                case 4:
                    return 2;
                default:
                    return 1;

            }
        }
        private void NoDealButton_Click(object sender, EventArgs e)
        {
            DealButton.Enabled = false;
            NoDealButton.Enabled = false;

            MakingOffer = false;
            CasesRemaining = CasesToOpen();
            InstructionsLabel.Text = $"Please select {CasesRemaining} cases";
            RoundNumber++;
        }

        private void DealButton_Click(object sender, EventArgs e)
        {
            DealButton.Enabled = false;
            NoDealButton.Enabled = false;
            string goodOrBad = "good";
            if (Convert.ToInt32(currentOffer.Text) < CaseValues[SelectedCase])
                goodOrBad = "bad";
            InstructionsLabel.Text = $"DEAL! Your case had {CaseValues[SelectedCase]}, you made a {goodOrBad} deal";

            System.IO.File.AppendAllText(Application.StartupPath + @"\scores.txt", UserName + ": " + currentOffer.Text + Environment.NewLine);
            LoadScores();
        }

        private void LoadScores()
        {
            string[] highScores = System.IO.File.ReadAllLines(Application.StartupPath + @"\scores.txt");
            List<int> highScoresIntegers = new List<int>();
            foreach (var score in highScores)
            {
                highScoresIntegers.Add(Convert.ToInt32(score.Substring(score.IndexOf(":")+1)));
            }
            Scores.Text = System.IO.File.ReadAllText(Application.StartupPath + @"\scores.txt");
            HighScore.Text = highScoresIntegers.Max().ToString();
            AverageScore.Text = Math.Round(highScoresIntegers.Average()).ToString();
        }

        private void Label6_Click(object sender, EventArgs e)
        {

        }

        private void SubmitName_Click(object sender, EventArgs e)
        {
            UserName = NameTextBox.Text;
            DealOfferPanel.Visible = true;
            UserNamePanel.Visible = false;
            InstructionsLabel.Text = "Please select your case";
        }

        private void CaseSelectionTimer_Tick(object sender, EventArgs e)
        {
            CaseSelectionTimer.Interval = 100;
            Color CurrentColor = ((sender as Timer).Tag as Button).ForeColor;
            int Red = CurrentColor.R;
            int Green = CurrentColor.G;
            int Blue = CurrentColor.B;
            if (Red < 20)
                Red = 0;
            else
                Red -= 20;

            if (Blue < 20)
                Blue = 0;
            else
                Blue -= 20;

            if (Green < 20)
                Green = 0;
            else
                Green -= 20;

            Color CurrentBackColor = ((sender as Timer).Tag as Button).BackColor;
            int BRed = CurrentBackColor.R;
            int BGreen = CurrentBackColor.G;
            int BBlue = CurrentBackColor.B;
            if (BRed < 20)
                BRed = 0;
            else
                BRed -= 20;

            if (BBlue < 20)
                BBlue = 0;
            else
                BBlue -= 20;

            if (BGreen < 20)
                BGreen = 0;
            else
                BGreen -= 20;


            foreach (var label in tableLayoutPanel2.Controls)
            {
                Button button = (sender as Timer).Tag as Button;
                int CaseNumber = Convert.ToInt32(button.Name.Replace("button", ""));

                if (label is Label)
                {
                    if ((label as Label).Name.Replace("lbl", "") == CaseValues[CaseNumber].ToString())
                    {
                        (label as Label).BackColor = Color.DarkGray;
                        (label as Label).ForeColor = Color.White;
                        break;
                    }
                }
            }


            if (Red == 0 && Green == 0 && Blue == 0 && BRed == 0 && BGreen == 0 && BBlue == 0)
            {
                AnimatingCase = false;
                CaseSelectionTimer.Interval = 3250;

                CaseSelectionTimer.Stop();
            }
            else
                AnimatingCase = true;

            ((sender as Timer).Tag as Button).ForeColor = Color.FromArgb(Red,Green,Blue);
            ((sender as Timer).Tag as Button).BackColor = Color.FromArgb(BRed, BGreen, BBlue);
            ((sender as Timer).Tag as Button).Text = ((sender as Timer).Tag as Button).Tag as String;
            ((sender as Timer).Tag as Button).Refresh();
        }
    }
}
